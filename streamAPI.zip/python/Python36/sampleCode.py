import mcmq
import traceback


def callback(message):
  try:
    '''
    {
      'type':     mcmq.messageType.subscribeTimeout,
      'userData': the data you passed before
    }
    '''
    if message['type'] is mcmq.messageType.subscribeTimeout:
      print('subscribeTimeout')
      #return mcmq.command.unsubscribe
      return # do nothing, will keep waiting message


    '''
    {
      'type':     mcmq.messageType.multiSegmentMessageTimeout,
      'topic':    string,    topic name,
      'logId':    string,    max 32 bytes unique ID to identify/track this message,
      'data':     bytearray, uncompleted data,
      'userData': the data you passed before
    }
    '''
    if message['type'] is mcmq.messageType.multiSegmentMessageTimeout:
      print('multiSegmentMessageTimeout: topic({}), logId({}), data({})'.format(
        message['topic'], message['logId'], message['data']
      ))
      #return mcmq.command.unsubscribe
      return # keep waiting next message


    '''
    {
      'type':     mcmq.messageType.getMessage,
      'topic':    string, topic name,
      'data':     string, topic data,
      'userData': the data you passed before
    }
    '''
    if message['type'] is mcmq.messageType.getMessage:
      print('getMessage: topic({}), dataLen({}), data100({})'.format(
        message['topic'], len(message['data']), message['data'][:100]
      ))
      #return mcmq.command.unsubscribe
      return # keep waiting next message


    '''
    {
      'type':     mcmq.messageType.requestCombineTopicKey,
      'topic':    string, topic name,
      'data':     string, topic data,
      'userData': the data you passed before
    }
    '''
    if message['type'] is mcmq.messageType.requestCombineTopicKey:
      print('requestCombineTopicKey: topic({}), data({})'.format(
        message['topic'], message['data']
      ))
      #return mcmq.command.unsubscribe
      #return 'someKey'
      return # means all messages use the same default key


    '''
    {
      'type': mcmq.messageType.getCombineTopicMessage,
      'key':  string, combine topic key
      'data': {
        'topicA': string or string list,
        'topicB': string or string list,
        ...
      },
      'userData': the data you passed before
    }
    '''
    if message['type'] is mcmq.messageType.getCombineTopicMessage:
      print('getCombineTopicMessage: key({}), data({})'.format(
        message['key'], message['data']
      ))
      #return mcmq.command.unsubscribe
      return # keep waiting next message


    '''
    {
      'type': mcmq.messageType.combineTopicTimeout,
      'key':  string, combine topic key
      'data': {
        'topicA': string or string list,
        'topicB': string or string list,
        ...
      },
      'userData': the data you passed before
    }
    '''
    if message['type'] is mcmq.messageType.combineTopicTimeout:
      print('combineTopicTimeout: key({}), data({})'.format(
        message['key'], message['data']
      ))
      #return mcmq.command.unsubscribe
      return # do nothing, will keep waiting message

  except:
    traceback.print_exc()
  finally:
    return


#======================================================================
# Main
#======================================================================
'''
mcmq.stream(host='localhost', port=6379, threadCheck=True)

  connect to redis and instance initialization.

  input:
    (optional)(str) host: connection host or IP
    (optional)(int) port: connection port
    (optional)(boolean) threadCheck:
      check if the function call thread is match the instance creator 
        default is True
      *** We strongly recommend not to change it unless you really know what it dose !!

  return:
    mcmq.stream instance
'''
try:
  stream = mcmq.stream(
    #host = '10.88.26.142',
    host = '192.168.56.103',
    #port = 8080
  )
except:
  traceback.print_exc()
  exit(0)


'''
subscribe(topic, callback, timeout=60, combineTopic=False, queueMessage=False, userData=None)

  subscribe topic.

  input:
    (required)(str, strList) topic:        topic name, ASCII 33~126 string only, max length 128 bytes
    (required)(function)     callback:     callback function when receiving message
    (optional)(int)          timeout:      timeout seconds, 0 for infinite wait
    (optional)(bool)         combineTopic: 
    (optional)(bool)         queueMessage: 
    (optional)(any)          userData:     any type of data that you want to pass

  return:
    None
'''
try:
  stream.subscribe( 
    # topic = 'topicA',   # can be string
    # topic = ['topicA'], # or string list, max length is 1000
    topic = ['topicA', 'topicB', 'topicABCDE'], 
    callback = callback, 
    timeout = 10,
    # combineTopic = True, 
    # queueMessage = True,
    # userData = None
  )
except:
  traceback.print_exc()
  exit(0)


'''
publish(topic, message, logId=None)

  publish message to topic.

  input:
    (required)(str) topic:   topic name, ASCII 33~126 string only, max length 128 bytes
    (required)(str) message: your message
    (optional)(str) logId:   unique ID to identify/track this message, max length 32 bytes
                             if not provide, API will auto generate and return it when publish success.

  return string logId or None:
    logId: publish success
    None:  publish fail
'''
# print(stream.publish(
#   'topicA', 
#   'abc中文頻道的中文訊息~!'
# ))


'''
exists(topic, timeout=60)

  check if topic was subscribed by anyone.

  input:
    (required)(str) topic:   topic name, ASCII 33~126 string only, max length 128 bytes
    (optional)(int) timeout: timeout seconds, 0 for infinite wait

  return boolean:
    True: topic exist, there has someone subscribe this topic
    False: topic not exist
'''
# print(stream.exists(
#   'topicA'
# ))
