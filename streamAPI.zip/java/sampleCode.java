import com.auo.cim.util.MCMQApi.MCMQStream;
import com.auo.cim.util.MCMQApi.MCMQStreamSubscriber;

public class sampleCode
{
	public static void main(String[] args)
	{
		try
		{
			// =====================================================================
			// MCMQStream(String host, int port, boolean threadCheck)
			//
			// connect to redis and instance initialization.
			//
			// input:
			//   (optional)(str) host: connection host or IP
			//                           default is localhost
			//   (optional)(int) port: connection port
			//                           default is 6379
			//	 (optional)(boolean) threadCheck: 
			//     check if the function call thread is match the instance creator 
			//       default is true     
			//     *** We strongly recommend not to change it unless you really know what it dose !!
			//
			// return:
			//   MCMQStream instance
			//
			// example:
			//   MCMQStream stream = new MCMQStream();
			//   MCMQStream stream = new MCMQStream("127.0.0.1");
			//   MCMQStream stream = new MCMQStream("127.0.0.1", 6379);
			//   MCMQStream stream = new MCMQStream("127.0.0.1", 6379, true);
			// =====================================================================
			MCMQStream stream = new MCMQStream("10.88.26.142", 8080);
			
			
			// =====================================================================
			// exists(String topic, int timeout)
			//
			// check if topic was subscribed by anyone.
			//
			// input:
			//   (required)(str) topic:   topic name, ASCII 33~126 string only, max length 128 bytes
			//   (optional)(int) timeout: timeout seconds, 0 for infinite wait
			//                            default is 60
			//
			// return boolean:
			//   true: topic exist, there has someone subscribe this topic
			//   false: topic not exist
			//
			// example:
			//   stream.exists("topic");
			//   stream.exists("topic", 0);  // infinite wait
			//   stream.exists("topic", 60); // wait 60s
			// =====================================================================
			System.out.println(
				String.format("exists: %b", stream.exists("topicA"))
			);
			
			
			// =====================================================================
			//	publish(String topic, String message, String logId)
			//
			//	  publish message to topic.
			//
			//	  input:
			//	    (required)(str) topic:   topic name, ASCII 33~126 string only, max length 128 bytes
			//	    (required)(str) message: your message
			//	    (optional)(str) logId:   unique ID to identify/track this message, max length 32 bytes 
			//	                             if not provide, API will auto generate and return it when publish success.
			//
			//	  return string logId or null:
			//	    logId: publish success
			//	    null:  publish fail
			//
			// example:
			//   stream.publish("topic", "message");
			//   stream.publish("topic", "message", "5cb1e7bf66d044d58763aa4646eebd3a");
			// =====================================================================
			System.out.println(
				String.format("publish: %s", stream.publish("topicA", "abc����T������~!@#$%^&*()_+"))
			);
			
			
			// =====================================================================
			//	subscribe(String[] topics, MCMQStreamSubscriber callback, int timeout, Object userData)
			//
			//	  subscribe message(s) from topic(s).
			//
			//	  input:
			//	    (required)(String[]) topics: 
			//        topic name array, each topic name should be ASCII 33~126 string only with max 128 bytes length
			//	    (required)(MCMQStreamSubscriber) callback: 
			//        callback functions when receiving message/timeout/...etc events happen
			//	    (optional)(int) timeout:
			//        timeout seconds, 0 for infinite wait, default is 60
			//      (optional)(Object) userData:
			//        user passed data, you can pass your personal defined data with Object type,
			//        when the callback happened, it will be passed back to you, just for convenience use
			//
			//	  return void:
      //      this function will be blocked till user return COMMAND.UNSUBSCRIBE in callback call
			// =====================================================================
			stream.subscribe(
				// topics, max length is 1000
				new String[]{"topicA", "topicB", "topicC"},
				
				// callback
				new MCMQStreamSubscriber() {
					
				  // ========================================
					// userData: the data you passed before
					// ========================================
					@Override
					public COMMAND subscribeTimeout(Object userData) {
						System.out.println(String.format(
							"subscribeTimeout: userData(%s)",
							(String)userData
						));
						
						//return COMMAND.UNSUBSCRIBE;
						return COMMAND.KEEP_WAIT;
					}
					
					// ========================================
					// topic:    the topic name
					// data:     the completed message
					// userData: the data you passed before
					// ========================================
					@Override
					public COMMAND getMessage(String topic, String data, Object userData) {
						System.out.println(String.format(
							"getMessage: topic(%s) message(%s) userData(%s)", 
							topic, data, (String)userData
						));
						
						return COMMAND.UNSUBSCRIBE;
						//return COMMAND.KEEP_WAIT;
					}
					
					// ========================================
					// topic:    the topic name
					// logId:    the max 32 bytes unique ID to identify/track this message
					// data:     the uncompleted message
					// userData: the data you passed before
					// ========================================
					@Override
					public COMMAND multiSegmentMessageTimeout(String topic, String logId, byte[] data, Object userData) {
						System.out.println(String.format(
							"multiSegmentMessageTimeout: topic(%s) logId(%s) userData(%s)", 
							topic, logId, (String)userData
						));
						
						return COMMAND.UNSUBSCRIBE;
						//return COMMAND.KEEP_WAIT;
					}
				},
				
				// timeout
				10,
				
				// userData
				"user data"
			);
			
			
		}
		catch (Exception ex)
    {
      System.out.println(ex.toString());
    }
	}
}
